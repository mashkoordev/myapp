package com.example.new_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
